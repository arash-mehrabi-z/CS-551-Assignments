Hi.

run genetic_optimizer.py file.

Sincerely.
